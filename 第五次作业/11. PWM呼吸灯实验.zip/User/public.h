#ifndef _public_H
#define _public_H

#include "stm32f10x.h"
void delay(u32 i);
void delayus(u32 i);
void delayms(u32 i);

#endif
